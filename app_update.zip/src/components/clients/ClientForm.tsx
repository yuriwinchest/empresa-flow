
// Re-export do novo módulo para manter compatibilidade com importações antigas
// Este arquivo agora serve apenas como "ponte" ou Proxy.

export { ClientForm } from "../../modules/clients/presentation/ClientForm";
