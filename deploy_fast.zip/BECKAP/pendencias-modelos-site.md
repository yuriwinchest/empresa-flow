# Pendências — Modelos "modelo - site" (CSV)

Atualizado em: 2025-12-28

## Tabela Geral

| Modelo (CSV) | O que falta (requisito do cliente) | Status hoje | Observação rápida |
|---|---|---|---|
| DOC1 | Upload Cartão CNPJ | Feito | Upload/listagem/abrir/remover na tela Empresas |
| DOC1 | Upload Certificado Digital A1 (.pfx) | Feito | Upload/listagem/abrir/remover na tela Empresas |
| DOC1 | Acesso/integração com emissão NF da prefeitura (NFS-e) | Parcial | Configuração de acesso na tela Empresas; falta integração de emissão |
| 1 CADASTRO DA EMPRESA | Mapear perfil (Serviço/Comércio/Mista) a partir do CNAE | Feito | Perfil calculado pelo CNAE (principal/secundários) |
| 1 CADASTRO DA EMPRESA | Habilitar módulos fiscais (NF-e/NFC-e/NFS-e) conforme perfil | Parcial | Flags enable_nfse/nfe/nfce e UI condicionada; falta emissão fiscal |
| 1 CADASTRO DA EMPRESA | Sugerir plano de contas por CNAE | Falta | Categorias existem, mas não há sugestão automática |
| 1 CADASTRO DA EMPRESA | Personalizar dashboard por tipo de atividade | Falta | Dashboard atual não muda por perfil |
| 1 CADASTRO DA EMPRESA | Integração bancária via OFX/API (importar extratos) | Falta | Página Conciliação é placeholder |
| 1 CADASTRO DA EMPRESA | Conciliação automática (cruzar crédito/débito com títulos) | Falta | Baixa é manual via modal (RPC) |
| 1 CADASTRO DA EMPRESA | Configurar boletos/pix para cobrança (Contas a Receber) | Falta | Existe “payment_method”, mas não gera cobrança |
| CADCPAGAR | Campo Competência (MM/AAAA) (base do DRE) | Falta | Tabelas usam due_date/payment_date, sem competência |
| CADCPAGAR | Campo Previsão de Pagamento (base do DFC) | Falta | Não existe “agendado/previsto” separado do vencimento |
| CADCPAGAR | Conta Corrente de Origem no título | Parcial | Só escolhe conta no momento da baixa |
| CADCPAGAR | Número NF / Chave de Acesso (anti-duplicidade/lastro) | Falta | Não há campos/validação para chave/nota |
| CADCPAGAR | Centro de Custo / Projeto | Falta | Não existe estrutura de centro de custo/projetos |
| CADCPAGAR | Anexo obrigatório (PDF/foto) para aprovação | Falta | Há file_url no banco, mas não há upload/visualização na UI |
| CADCPAGAR | Fluxo de status Pendente → Conferido → Aprovado → Pago (pós-conciliação) | Falta | Hoje: pending/paid/cancelled/overdue |
| CADCRECEBER | Campo Competência (MM/AAAA) | Falta | Mesmo ponto: não existe competência |
| CADCRECEBER | Conta bancária de destino no título | Parcial | Só escolhe conta no momento da baixa/recebimento |
| CADCRECEBER | Impostos retidos/deduções automáticas (ISS/PIS/COFINS/taxa cartão) | Falta | Não há cálculo/armazenamento dessas deduções |
| CADCRECEBER | Chave/Número da nota gerada | Falta | Não há emissão fiscal nem campo de chave |
| CADCRECEBER | Status Aguardando faturamento / Pendente / Em atraso / Recebido | Falta | Status atual é genérico (pending/paid/...) |
| GRÁFRELAT | DRE por competência (Receita líquida vs custos/despesas) | Parcial | Relatórios atuais usam transactions.date (caixa), não competência |
| GRÁFRELAT | Margem bruta e lucro líquido | Falta | Precisa regra de COGS/custos vs despesas e impostos/deduções |
| GRÁFRELAT | Pareto (ABC) de receitas/despesas (por cliente/categoria) | Parcial | Tem “Top categorias”, mas não ABC nem lucro por cliente |
| GRÁFRELAT | DFC “realizado” via conciliação OFX | Falta | Conciliação não implementada |
| GRÁFRELAT | Inadimplência (total vencido não recebido) | Falta | Não há card/relatório específico de inadimplência |
| GRÁFRELAT | Projeção 6 meses (saldo projetado com recorrências/agendados) | Falta | Recorrência existe, mas não gera projeções/títulos futuros |
| GRÁFRELAT | Real vs Orçado (Budget) | Falta | Não existe módulo de orçamento/metas |
| GRÁFRELAT | Ponto de equilíbrio (dia do mês) | Falta | Depende de orçamento + projeções/recorrências |
| GRÁFRELAT | Carga de impostos/deduções (pizza) | Falta | Depende do cálculo de deduções/impostos por receita |

## Tabelas por Modelo

### DOC1

| O que falta (requisito do cliente) | Status hoje | Observação rápida |
|---|---|---|
| Upload Cartão CNPJ | Feito | Upload/listagem/abrir/remover na tela Empresas |
| Upload Certificado Digital A1 (.pfx) | Feito | Upload/listagem/abrir/remover na tela Empresas |
| Acesso/integração com emissão NF da prefeitura (NFS-e) | Parcial | Configuração de acesso na tela Empresas; falta integração de emissão |

### 1 CADASTRO DA EMPRESA

| O que falta (requisito do cliente) | Status hoje | Observação rápida |
|---|---|---|
| Mapear perfil (Serviço/Comércio/Mista) a partir do CNAE | Feito | Perfil calculado pelo CNAE (principal/secundários) |
| Habilitar módulos fiscais (NF-e/NFC-e/NFS-e) conforme perfil | Parcial | Flags enable_nfse/nfe/nfce e UI condicionada; falta emissão fiscal |
| Sugerir plano de contas por CNAE | Falta | Categorias existem, mas não há sugestão automática |
| Personalizar dashboard por tipo de atividade | Falta | Dashboard atual não muda por perfil |
| Integração bancária via OFX/API (importar extratos) | Falta | Página Conciliação é placeholder |
| Conciliação automática (cruzar crédito/débito com títulos) | Falta | Baixa é manual via modal (RPC) |
| Configurar boletos/pix para cobrança (Contas a Receber) | Falta | Existe “payment_method”, mas não gera cobrança |

### CADCPAGAR

| O que falta (requisito do cliente) | Status hoje | Observação rápida |
|---|---|---|
| Campo Competência (MM/AAAA) (base do DRE) | Falta | Tabelas usam due_date/payment_date, sem competência |
| Campo Previsão de Pagamento (base do DFC) | Falta | Não existe “agendado/previsto” separado do vencimento |
| Conta Corrente de Origem no título | Parcial | Só escolhe conta no momento da baixa |
| Número NF / Chave de Acesso (anti-duplicidade/lastro) | Falta | Não há campos/validação para chave/nota |
| Centro de Custo / Projeto | Falta | Não existe estrutura de centro de custo/projetos |
| Anexo obrigatório (PDF/foto) para aprovação | Falta | Há file_url no banco, mas não há upload/visualização na UI |
| Fluxo de status Pendente → Conferido → Aprovado → Pago (pós-conciliação) | Falta | Hoje: pending/paid/cancelled/overdue |

### CADCRECEBER

| O que falta (requisito do cliente) | Status hoje | Observação rápida |
|---|---|---|
| Campo Competência (MM/AAAA) | Falta | Mesmo ponto: não existe competência |
| Conta bancária de destino no título | Parcial | Só escolhe conta no momento da baixa/recebimento |
| Impostos retidos/deduções automáticas (ISS/PIS/COFINS/taxa cartão) | Falta | Não há cálculo/armazenamento dessas deduções |
| Chave/Número da nota gerada | Falta | Não há emissão fiscal nem campo de chave |
| Status Aguardando faturamento / Pendente / Em atraso / Recebido | Falta | Status atual é genérico (pending/paid/...) |

### GRÁFRELAT

| O que falta (requisito do cliente) | Status hoje | Observação rápida |
|---|---|---|
| DRE por competência (Receita líquida vs custos/despesas) | Parcial | Relatórios atuais usam transactions.date (caixa), não competência |
| Margem bruta e lucro líquido | Falta | Precisa regra de COGS/custos vs despesas e impostos/deduções |
| Pareto (ABC) de receitas/despesas (por cliente/categoria) | Parcial | Tem “Top categorias”, mas não ABC nem lucro por cliente |
| DFC “realizado” via conciliação OFX | Falta | Conciliação não implementada |
| Inadimplência (total vencido não recebido) | Falta | Não há card/relatório específico de inadimplência |
| Projeção 6 meses (saldo projetado com recorrências/agendados) | Falta | Recorrência existe, mas não gera projeções/títulos futuros |
| Real vs Orçado (Budget) | Falta | Não existe módulo de orçamento/metas |
| Ponto de equilíbrio (dia do mês) | Falta | Depende de orçamento + projeções/recorrências |
| Carga de impostos/deduções (pizza) | Falta | Depende do cálculo de deduções/impostos por receita |
